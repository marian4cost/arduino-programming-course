const int leds[] = {8, 9, 10};
const int quantidade = sizeof(leds) / sizeof(leds[0]);
const int botao = 2;

void piscarLed(int pino, int duracaoMs) {
  digitalWrite(pino, HIGH);
  delay(duracaoMs);
  digitalWrite(pino, LOW);
}

void setup() {
  pinMode(botao, INPUT_PULLUP);

  for (int i = 0; i < quantidade; i++) {
    pinMode(leds[i], OUTPUT);
  }
}

void loop() {
  for (int i = 0; i < quantidade; i++) {
    bool pressionado = digitalRead(botao) == LOW;
    int tempoMs = 400;

    if (pressionado) {
      tempoMs = 150;
    }

    piscarLed(leds[i], tempoMs);
  }
}
