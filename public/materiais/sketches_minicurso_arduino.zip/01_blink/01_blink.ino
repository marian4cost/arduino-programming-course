const int led = 8;
const int tempoMs = 500;

void setup() {
  // Configura D8 para controlar o LED externo.
  pinMode(led, OUTPUT);
}

void loop() {
  // HIGH acende o LED durante tempoMs.
  digitalWrite(led, HIGH);
  delay(tempoMs);

  // LOW apaga o LED pelo mesmo tempo.
  digitalWrite(led, LOW);
  delay(tempoMs);
}
