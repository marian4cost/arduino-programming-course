const int led = LED_BUILTIN;
const int tempoMs = 500;

void setup() {
  pinMode(led, OUTPUT);
}

void loop() {
  digitalWrite(led, HIGH);
  delay(tempoMs);
  digitalWrite(led, LOW);
  delay(tempoMs);
}
