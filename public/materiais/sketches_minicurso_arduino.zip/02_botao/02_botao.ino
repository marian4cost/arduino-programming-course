const int botao = 2;
const int led = LED_BUILTIN;

void setup() {
  pinMode(botao, INPUT_PULLUP);
  pinMode(led, OUTPUT);
}

void loop() {
  bool pressionado = digitalRead(botao) == LOW;
  if (pressionado) {
    digitalWrite(led, HIGH);
  } else {
    digitalWrite(led, LOW);
  }
}
