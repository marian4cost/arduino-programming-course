const int botao = 2;
const int led = 8;

void setup() {
  // Com o botão solto, D2 lê HIGH.
  pinMode(botao, INPUT_PULLUP);
  pinMode(led, OUTPUT);
}

void loop() {
  // Ao pressionar, D2 é ligado ao GND.
  bool acender = digitalRead(botao) == LOW;
  if (acender) {
    digitalWrite(led, HIGH);
  } else {
    digitalWrite(led, LOW);
  }
}
