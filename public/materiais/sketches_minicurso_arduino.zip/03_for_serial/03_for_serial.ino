void setup() {
  Serial.begin(9600);
  for (int i = 0; i < 3; i++) {
    Serial.println(i);
  }
}

void loop() {
}
