const int leds[] = {8, 9, 10};
const int quantidade = sizeof(leds) / sizeof(leds[0]);
const int tempoMs = 400;

void piscarLed(int pino, int duracaoMs) {
  digitalWrite(pino, HIGH);
  delay(duracaoMs);
  digitalWrite(pino, LOW);
}

void setup() {
  for (int i = 0; i < quantidade; i++) {
    pinMode(leds[i], OUTPUT);
  }
}

void loop() {
  for (int i = 0; i < quantidade; i++) {
    piscarLed(leds[i], tempoMs);
  }
}
